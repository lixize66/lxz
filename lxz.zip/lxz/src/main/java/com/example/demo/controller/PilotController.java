package com.example.demo.controller;

import com.alibaba.fastjson.JSON;
import com.example.demo.entity.Issuetext;
import com.example.demo.entity.Pilot;
import com.example.demo.service.PilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class PilotController {
    @Autowired
    private PilotService pilotService;

    @RequestMapping("/issue")
    public String issue(){
        return "issue";
    }

    @RequestMapping("/insertpilot")
    @ResponseBody
    public String insertpilot(@RequestBody String str){
        Issuetext issue= JSON.parseObject(str, Issuetext.class);
//        System.out.println(issue);
        pilotService.insert(issue);
        return issue.toString();
    }
    @RequestMapping("/getpilotbytype")
    @ResponseBody
    public List<Pilot> getpilotbytype(){
        System.out.println("ax");
        return pilotService.selectbytype(1);
    }
}
