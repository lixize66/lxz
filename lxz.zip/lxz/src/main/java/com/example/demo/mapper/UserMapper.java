package com.example.demo.mapper;

import com.example.demo.entity.User;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author:0xOO
 * @Date: 2018/9/26 0026
 * @Time: 15:20
 */
@Repository
public interface UserMapper {
    List<User> getall();
    User selectByName(String username);
    User select(int id);
    int insert(User user);
    int delete(int id);
    int update(User user);
}
