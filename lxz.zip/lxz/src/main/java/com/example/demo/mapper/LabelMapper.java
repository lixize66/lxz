package com.example.demo.mapper;

import com.example.demo.entity.Label;
import com.example.demo.entity.Pilot;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LabelMapper {
    List<Label> selectbytype(int type);
    List<Label> selectbyid(int id);
    int insert(Label label);
}
