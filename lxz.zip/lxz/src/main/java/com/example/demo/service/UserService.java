package com.example.demo.service;


import com.example.demo.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.User;
/**
 * @Author:0xOO
 * @Date: 2018/9/26 0026
 * @Time: 15:23
 */
@Service
public class UserService {
    @Autowired
    UserMapper userMapper;
    public User select(int id){
        return userMapper.select(id);
    }
    public String insert(String usernme,String password){
        if (userMapper.selectByName(usernme)==null){
            User user=new User(null,usernme,password);
            userMapper.insert(user);
            return "创建成功";
        }
        else {
            return "用户已存在";
        }
    }
    public void delete(int id){
        userMapper.delete(id);
    }
    public void uptade(User user){
        userMapper.update(user);
    }
    public String logingetId(String usernme,String password)
    {
        User user= userMapper.selectByName(usernme);
        if(user==null){
            return "用户名不存在";
        }
        else if (!user.getPassWord().equals(password)){
            return "密码错误";
        }
        return user.getId().toString();
    }

}
