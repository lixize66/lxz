package com.example.demo.controller;

import com.example.demo.entity.User;


import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @Author:0xOO
 * @Date: 2018/9/26 0026
 * @Time: 14:42
 */

@Controller
public class UserController {

    @Autowired
    private UserService userService;
    @RequestMapping("/index")
    public String index() {

        return "index";
    }
    @RequestMapping("/login")
    public String login() {

        return "login";
    }
    @RequestMapping("/register")
    public String register() {

        return "register";
    }

    @RequestMapping( "/getuser")
    @ResponseBody
    public String GetUser(@RequestParam(value = "username",required = false) String username,
                          @RequestParam( value = "password",required = false) String password)
    {
        return userService.logingetId(username,password);
    }

    @RequestMapping( "/insertuser")
    @ResponseBody
    public String insertuser(@RequestParam(value = "username",required = false) String username,
                          @RequestParam( value = "password",required = false) String password)
    {
        System.out.println(username+password);
        return userService.insert(username,password);
    }

}
