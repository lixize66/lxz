package com.example.demo.mapper;

import com.example.demo.entity.Pilot;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PilotMapper {
    List<Pilot> getall();
    List<Pilot> selectByName(String authorname);
    List<Pilot> selectbytype(int type);
    Pilot select(int id);
    int insert(Pilot pilot);
    int delete(int id);
    int update(Pilot pilot);

}
