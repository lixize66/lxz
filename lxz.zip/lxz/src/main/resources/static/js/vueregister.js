var vc =new Vue({
    el:"#register",
    data: {
        messageUsername:"",
        messagePassword:"",
        messageconfirm:"",
        rejisterUser:{
            username:"",
            password:"",
            confirmpassword:""
        }

    },
    methods:{

        registerclick(){
            let is=true;
            if (this.rejisterUser.username == null || this.rejisterUser.username == "" || this.rejisterUser.username == undefined){
                this.messageUsername="用户名不能为空";
                is=false;
            }else {
                this.messageUsername="";
            }
            if (this.rejisterUser.password == null || this.rejisterUser.password == "" || this.rejisterUser.password == undefined){
                this.messagePassword="用户名不能为空";
                is=false;
            }else {
                this.messagePassword="";
            }
            if (!this.messagePassword==this.messageconfirm){
                this.messageconfirm="密码不一致";
                is=false;
            }else {
                this.messageconfirm="";
            }
            if (is){
            axiosPostRequst("http://localhost:8087/insertuser",this.rejisterUser).then(result=>{
                console.log(result);
                localStorage.setItem("username",this.rejisterUser.username);
            });
        }
        },





    }
})