package com.example.demo.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pilot {
    private int id;
    private String authorname;
    private Date data;
    private int authorid;
    private String url;
    private String imgurl;
    private int type;
    private String title;
}
