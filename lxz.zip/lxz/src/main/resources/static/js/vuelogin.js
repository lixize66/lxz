
 var vc =new Vue({
    el:"#login",
    data: {
        messageUsername:"",
        messagePassword:"",
        User:{
            id:"",
            username:localStorage.getItem("username"),
            password:""
        }

    },
    methods:{

        loginclick(){
            let is=true;
            if (this.User.username == null || this.User.username == "" || this.User.username == undefined){
                this.messageUsername="用户名不能为空";
                is=false;
            }else {
                this.messageUsername="";
            }
            if (this.User.password == null || this.User.password == "" || this.User.password == undefined){
                this.messagePassword="用户名不能为空";
                is=false;
            }else {
                this.messagePassword="";
            }
            if (is){
          axiosPostRequst("http://localhost:8087/getuser",this.User).then(result=>{
              console.log(result);
              if (result=="用户名不存在"){
                  this.messageUsername=result;
              }else if (result=="密码错误"){
                  this.messagePassword=result
              }else {
                  // this.User.id=result;
                  localStorage.setItem("userid",result.toString())
                  alert("登录成功");
                  history.back(-1);

              }
             localStorage.setItem("username",this.User.username);

          });
            }
        },





    }
})