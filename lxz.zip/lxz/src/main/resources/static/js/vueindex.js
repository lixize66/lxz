var vv =new Vue({
el:"#content",
    data:{
        con:[

        ]

    }
})
var text={
    id:12,
    authorname:"ji",
    data:"",
    authorid:"",
    url:"",
    imgurl:"",
    type:"",
    title:"啊啊啊啊啊啊啊啊"
}
window.onload=function(){
    axiosPostRequst("http://localhost:8087/getpilotbytype",null).then(result=>{
        for (var i=0;i<result.length;i++){
            vv.con.push(result[i])
        }
    });
    if (localStorage.getItem("userid")){
        document.getElementById("logintext").innerText=localStorage.getItem("username")
    }
}

