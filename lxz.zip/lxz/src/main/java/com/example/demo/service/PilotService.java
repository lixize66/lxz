package com.example.demo.service;

import com.example.demo.entity.Issuetext;
import com.example.demo.entity.Pilot;
import com.example.demo.mapper.PilotMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;
@Service
public class PilotService {
    @Autowired
    PilotMapper pilotMapper;
    public Pilot select(int id){
        Pilot pilot=pilotMapper.select(id);
        return pilot;
    }
    public List<Pilot> selectbytype(int type){
        return pilotMapper.selectbytype(type);
    }
    public List<Pilot> selectbyname(String name){
        return pilotMapper.selectByName(name);
    }
    public void insert(Issuetext issuetext){
        Pilot pilot=new Pilot();
        pilot.setAuthorid(issuetext.getAuthorid());
        pilot.setAuthorname(issuetext.getAuthorname());
        Date date=new Date();
        System.out.println(date);
        pilot.setData(new java.sql.Date(date.getTime()));
        pilot.setType(issuetext.getType());
        pilot.setTitle(issuetext.getTitle());
        System.out.println(pilot);
        pilotMapper.insert(pilot);
    }
}
